package com;

import java.util.Scanner;

import com.revature.bms.dao.CustomerDAOImpl;
import com.revature.bms.exceptions.LowBalanceException;
import com.revature.bms.exceptions.NegativeBalanceException;
import com.revature.bms.model.Customer;

public class CustomerAfterLoginForm {
	static Scanner sc = new Scanner(System.in);
	static CustomerDAOImpl customerDAOImpl = new CustomerDAOImpl();

	public static void viewBalance(Customer customer) {

		int balance = customerDAOImpl.getCustomerBalanceFromID(customer.getCustomerId());
		System.out.println(customer.getCustomerName() + " your current balance of account is " + balance);
		getCustomerOperation(customer);
	}

	public static void depositeAmmount(Customer customer) {
		try {
			System.out.println("#######################################################");
			System.out.println("Welcome to deposite section");
			System.out.println(customer.getCustomerName() + " how much ammount will you like to deposite==>");
			int depositedBalance = sc.nextInt();
			if(depositedBalance<0) {
				throw new NegativeBalanceException("Deposited Ammount can not be negative...........");
			}
			boolean flag = customerDAOImpl.depositeCustomerAmmount(customer.getCustomerId(), depositedBalance);
			if (flag == true) {
				System.out.println("Balance updated successfully");
				//getCustomerOperation(customer);
			} else {
				System.out.println("Balance updated successfully");
				//getCustomerOperation(customer);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		finally {
			getCustomerOperation(customer);
		}
	}

	public static void withdrawAmmount(Customer customer) {
		try {
			System.out.println("Welcome to withdraw section");
			System.out.println(customer.getCustomerName() + " how much ammount will you like to withdraw==>");
			int withdrawBalance = sc.nextInt();
			if(withdrawBalance<0) {
				throw new NegativeBalanceException("Withdraw ammount can not be negative...........");
			}
			
			else if((customer.getCustomerBalance()-withdrawBalance)<0){
				throw new LowBalanceException("You have not enough balance to perform operation");
			}
			boolean flag = customerDAOImpl.withdrawCustomerAmmount(customer.getCustomerId(), withdrawBalance);
			if (flag == true) {
				System.out.println("Balance updated successfully");
				//getCustomerOperation(customer);
			} else {
				System.out.println("Balance updated successfully");
				//getCustomerOperation(customer);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		finally {
			getCustomerOperation(customer);
		}
	}

	public static void transferAmmount(Customer customer) {
		try {
			System.out.println("Welcome to withdraw section");
			System.out.println(customer.getCustomerName() + " whom would you like to transfer the ammount?");
			System.out.println("Enter the customer id whom you wanna tarnsfer==>");
			int transferID = sc.nextInt();
			System.out.println("Enter the ammount to transfer==>");
			int transferAmmount = sc.nextInt();
			if (transferAmmount < 0) {
				throw new NegativeBalanceException("Transfer ammount can not be nagative.......");
			}
			else if((customer.getCustomerBalance()-transferAmmount)<0) {
				throw new LowBalanceException("You have not enough balance to perform this operation");
			}
			boolean flag1 = customerDAOImpl.withdrawCustomerAmmount(customer.getCustomerId(), transferAmmount);
			boolean flag2 = customerDAOImpl.depositeCustomerAmmount(transferID, transferAmmount);
			if (flag1 == true && flag2 == true) {
				System.out.println("Transaction successfull");
				getCustomerOperation(customer);
			} else {
				System.out.println("Transaction fail");
				getCustomerOperation(customer);
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		} finally {
			getCustomerOperation(customer);
		}
	}

	public static void deleteCustomerAccount(Customer customer) {
		System.out.println("Are you sure you wanna delete(Yes/No)==>");
		String choice = sc.next();
		if (choice.equalsIgnoreCase("Yes")) {
			boolean flag = customerDAOImpl.deleteCustomer(customer.getCustomerId());
			if (flag == true) {
				System.out.println("Deleted Successfuly");
			} else {
				System.out.println("UnSuccessfuly");
			}
			WelcomeForm.getWelcomeForm();
		} else {
			getCustomerOperation(customer);
		}

	}

	public static void getCustomerOperation(Customer customer) {

		System.out.println("Welcome " + customer.getCustomerName());
		System.out.println("What would you like to do??");
		System.out.println("1. View Balance");
		System.out.println("2. Transfer Ammount");
		System.out.println("3. Deposite Ammount");
		System.out.println("4. Withdraw Ammount");
		System.out.println("5. Delete Account");
		System.out.println("6. Go to main menu");
		System.out.println("7. E X I  T");
		System.out.println("Enter your choice==>");
		int choice = sc.nextInt();
		switch (choice) {
		case 1:
			viewBalance(customer);
			break;
		case 2:
			transferAmmount(customer);
			break;
		case 3:
			depositeAmmount(customer);
			break;
		case 4:
			withdrawAmmount(customer);
			break;
		case 5:
			deleteCustomerAccount(customer);
			break;
		case 6:
			WelcomeForm.getWelcomeForm();
			break;
		case 7:
			System.exit(0);
		}
	}

}
