package com;

import java.util.Scanner;

public class LoginForm {
	public static void getLoginAccountForm() {
		
		System.out.println("#######################################################");
		System.out.println("\t Welcome to login section");
		System.out.println("#######################################################");
		System.out.println("1. Login To Employee Account");
		System.out.println("2. Login To Customer Account");
		System.out.println("3. Go to main menu");
		System.out.println("4. E X I T");
		System.out.println("Enter your choice==>");
		Scanner sc=new Scanner(System.in);
		int choice=sc.nextInt();
		
		switch(choice) {
			case 1:
				EmployeeLoginForm.loginToEmployeeAccount();
				break;
			case 2:
				CustomerLoginForm.loginToCustomerAccount();
				break;
			case 3:
				WelcomeForm.getWelcomeForm();
				break;
			case 4:
				System.out.print("Thank you for visiting......");
				System.exit(0);
				break;
		}
		
	}
}
