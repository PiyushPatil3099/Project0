package com;

import java.util.Scanner;

import org.apache.log4j.Logger;

public class CreateAccountForm {
	private static Logger logger=Logger.getLogger("BankApp");
	public static void getCreateAccountForm() {
		logger.info("[User used create account option]");
		System.out.println("#######################################################");
		System.out.println("\t Welcome to create/open account section");
		System.out.println("#######################################################");
		System.out.println("1. Create Employee Account");
		System.out.println("2. Create Customer Account");
		System.out.println("3. Go to main menu");
		System.out.println("4. E X I T");
		System.out.println("Enter your choice===>");
		Scanner sc=new Scanner(System.in);
		int choice=sc.nextInt();
		
		switch(choice) {
			case 1:
				CreateEmployeeAccountForm.createEmployeeAccount();
				break;
			case 2:
				CreateCustomerAccountForm.createCustomerAccount();
				break;
			case 3:
				WelcomeForm.getWelcomeForm();
				break;
			case 4:
				System.out.print("Thank you for visiting......");
				System.exit(0);
				break;
		}
		
	}
}
