package com;

import java.util.Scanner;

import com.revature.bms.dao.EmployeeDaoImpl;
import com.revature.bms.model.Employee;

public class EmployeeLoginForm {
	
	public static void loginToEmployeeAccount() {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("#######################################################");
		System.out.println("Enter the employee user name=");
		String employeeUserName=sc.next();
		System.out.println("Enter the employee password=");
		String employeePassword=sc.next();
		System.out.println("#######################################################");
		EmployeeDaoImpl employeeDaoImpl=new EmployeeDaoImpl();
		boolean mark=employeeDaoImpl.validateEmployee(employeeUserName, employeePassword);
		if(mark==true) {	
			
			Employee employee=employeeDaoImpl.getEmployeeUsingUsernamePassword(employeeUserName, employeePassword);
			EmployeeOprationForm.getEmployeeOperations(employee);
		}
		else
		{
			System.out.println("Invalid user");
			LoginForm.getLoginAccountForm();
		}
	}

}
