

package com;

import java.util.Date;
import java.util.Scanner;
import org.apache.log4j.Logger;
public class WelcomeForm {
	private static Logger logger=Logger.getLogger("BankApp");
	public static void getWelcomeForm() {
		logger.info("BANK APP STARTED"+new Date());
		Scanner sc = new Scanner(System.in);
		System.out.println("#######################################################");
		System.out.println("\t Piyush Banking App");
		System.out.println("#######################################################");
		System.out.println("1. Login");
		System.out.println("2. Create Account");
		System.out.println("3. Know more about banking app");
		System.out.println("4. Know about developers - Piyush");
		System.out.println("10.E X I T");
		System.out.println("Enter your choice==>");
		int choice = sc.nextInt();
		switch (choice) {
		case 1:
			LoginForm.getLoginAccountForm();
			break;
		case 2:
			CreateAccountForm.getCreateAccountForm();
			break;
		case 3:
			break;
		case 4:
			break;
		case 10:
			break;
		}
	}
}
