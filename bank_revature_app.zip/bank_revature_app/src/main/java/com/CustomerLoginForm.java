package com;

import java.util.Scanner;

import com.revature.bms.dao.CustomerDAOImpl;
import com.revature.bms.model.Customer;


public class CustomerLoginForm {
	
	public static void loginToCustomerAccount() {
		
		Scanner sc=new Scanner(System.in);	
		System.out.println("#######################################################");
		System.out.println("Enter the customer user name=");
		String customerUserName=sc.next();
		System.out.println("Enter the customer password=");
		String customerPassword=sc.next();
		System.out.println("#######################################################");
		
		
		CustomerDAOImpl customerDaoImpl=new CustomerDAOImpl();
		boolean mark=customerDaoImpl.validateCustomer(customerUserName, customerPassword);
		if(mark==true) {	
			System.out.println("Valid User");
			Customer customer=customerDaoImpl.getCustomerIdFromUsernamePassword(customerUserName, customerPassword);
			CustomerAfterLoginForm.getCustomerOperation(customer);
		}
		else
		{
			System.out.println("Invalid user");
			LoginForm.getLoginAccountForm();
		}
	}

}
