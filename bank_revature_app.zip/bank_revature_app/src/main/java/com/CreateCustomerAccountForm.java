package com;

import java.util.Scanner;

import org.apache.log4j.Logger;

import com.revature.bms.dao.CustomerDAOImpl;
import com.revature.bms.exceptions.CustomerAlreadyExistException;
import com.revature.bms.exceptions.NegativeBalanceException;
import com.revature.bms.model.Customer;

public class CreateCustomerAccountForm {
	private static Logger logger=Logger.getLogger("BankApp");
	public static void createCustomerAccount() {
			logger.info("[Customer creating an account..........]");
		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("#######################################################");
			System.out.println("\t Welcome to Customer Account Creation Section");
			System.out.println("#######################################################");
			System.out.println("\n ***********Please Enter The Following Details*************");
			System.out.println("Enter The customer Id==>");
			int customerId = sc.nextInt();
			System.out.println("Enter The Customer Name==>");
			String customerName = sc.next();
			System.out.println("Enter The Customer Address==>");
			String customerAddress = sc.next();
			System.out.println("Enter The Customer Account Initial Balance==>");
			int customerBalance = sc.nextInt();
			if(customerBalance<0) {
				throw new NegativeBalanceException("Account can not have negative balance");
			}
			System.out.println("Enter The User Name For Customer==>");
			String customerUserName = sc.next();
			System.out.println("Enter the Password==>");
			String customerPassword = sc.next();

			CustomerDAOImpl customerDAOImpl = new CustomerDAOImpl();
			if (customerDAOImpl.isCustomerAlreadyExist(customerId)) {
				logger.error("[Customer already exist]");
				throw new CustomerAlreadyExistException("Same id customer already exist in the system......");
			} else {

				Customer customer = new Customer(customerId, customerName, customerAddress, customerBalance,
						customerUserName, customerPassword);

				boolean mark = customerDAOImpl.addAppliedCustomer(customer);
				if (mark == true) {
					logger.info("[Customer Added Successfully..........]");
					System.out.println("Customer Added Successfully");
				} else {
					System.out.println("Customer Not Added Successfully");
					logger.info("[Customer Added Successfully..........]");
					
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		finally {
			WelcomeForm.getWelcomeForm();
		}
	}

}
