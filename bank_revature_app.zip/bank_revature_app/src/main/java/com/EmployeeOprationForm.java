package com;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.revature.bms.dao.CustomerDAOImpl;
import com.revature.bms.dao.EmployeeDaoImpl;
import com.revature.bms.model.Customer;
import com.revature.bms.model.Employee;



public class EmployeeOprationForm {
	static Scanner sc=new Scanner(System.in);
	static EmployeeDaoImpl employeeDaoImpl=new EmployeeDaoImpl();
	public static void showAllCustomerData(Employee employee) {
		System.out.println("Heres the all data you wanna==>");
		List<Customer> list=employeeDaoImpl.getAllCustomerAccounts();
		Iterator<Customer> i=list.iterator();
		while(i.hasNext()) {
			Customer temp=i.next();
			System.out.println(temp);
		}
		getEmployeeOperations(employee);
	}
	public static void deleteEmployeeData(Employee employee) {
		System.out.println("Are you sure u wanna delete account(Yes/No)==>");
		String choice=sc.next();
		if(choice.equalsIgnoreCase("Yes")) {
			employeeDaoImpl.deleteEmployee(employee.getEmployeeId());
			WelcomeForm.getWelcomeForm();
		}
		else {
			getEmployeeOperations(employee);
		}
	}
	public static void viewCustomerAppliedNewly(Employee employee) {
		
		List<Customer> l=employeeDaoImpl.getAppliedCustomerAccounts();
		Iterator<Customer> i=l.iterator();
		while(i.hasNext()) {
			Customer temp=i.next();
			System.out.println(temp);
		}
		System.out.println("Would you like to Approve/Reject Accounts(Yes/No)==>");
		String choice=sc.next();
		if(choice.equalsIgnoreCase("Yes")) {
			System.out.println("Enter the account id on which you wanna perform Approve/Reject operation==>");
			int customerId=sc.nextInt();
			System.out.println("Enetr the status (Approved/Rejected)==>");
			String status=sc.next();
			if(status.equalsIgnoreCase("Approved")) {
				Iterator<Customer> j=l.iterator();
				while(j.hasNext()) {
					Customer temp=j.next();
					if(temp.getCustomerId()==customerId) {
						new CustomerDAOImpl().addCustomer(temp);
						new CustomerDAOImpl().deleteAppliedCustomer(customerId);
						getEmployeeOperations(employee);
						System.out.println("Account aproved");
					}
				}
			}
			else {
				new CustomerDAOImpl().deleteAppliedCustomer(customerId);
				getEmployeeOperations(employee);
			}
		}
		else
		{
			getEmployeeOperations(employee);
		}
	}
	public static void getEmployeeOperations(Employee employee) {
		System.out.println("#######################################################");
		System.out.println("Welcome "+employee.getEmployeeName());
		System.out.println("What would you like to do??");
		System.out.println("#######################################################");
		System.out.println("1. View Customer Accounts");
		System.out.println("2. Delete Your Account");
		System.out.println("3. View Customer Applied For New Account");
		System.out.println("4. Go to main menu");
		System.out.println("5. E X I T");
		System.out.println("Enter your choice==>");
		int choice=sc.nextInt();
		switch(choice) {
			case 1:
				showAllCustomerData(employee);
				break;
			case 2:
				deleteEmployeeData(employee);
				break;
			case 3:
				viewCustomerAppliedNewly(employee);
				break;
				
			case 4:
				WelcomeForm.getWelcomeForm();
				break;
			case 5:
				System.exit(0);
				break;
		}
		
	}

}
