package com;

import java.util.Scanner;

import com.revature.bms.dao.EmployeeDaoImpl;
import com.revature.bms.exceptions.EmployeeAlreadyExistException;
import com.revature.bms.model.Employee;

public class CreateEmployeeAccountForm {

	public static void createEmployeeAccount() {

		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("#######################################################");
			System.out.println("\t Welcome to Employee Account Creation Section");
			System.out.println("#######################################################");
			System.out.println("\n ***********Please Enter The Following Details*************");
			System.out.println("Enter The Employee Id==>");
			int employeeId = sc.nextInt();
			System.out.println("Enter The Employee Name==>");
			String employeeName = sc.next();
			System.out.println("Enter The User Name For Employee==>");
			String employeeUserName = sc.next();
			System.out.println("Enter the Password==>");
			String employeePassword = sc.next();
			EmployeeDaoImpl employeeDaoImpl = new EmployeeDaoImpl();
			if (employeeDaoImpl.isEmployeeAlreadyExist(employeeId)) {
				throw new EmployeeAlreadyExistException("Employee with this id already exist in system");
			} else {
				Employee employee = new Employee(employeeId, employeeName, employeeUserName, employeePassword);

				boolean mark = employeeDaoImpl.addEmployee(employee);
				if (mark == true)
					System.out.println("Employee Added Successfully");
				else
					System.out.println("Employee can not be added");

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		finally {
			WelcomeForm.getWelcomeForm();
		}

	}
}
