package com.revature.bms.exceptions;

public class NegativeBalanceException extends RuntimeException {
	public NegativeBalanceException() {
		// TODO Auto-generated constructor stub
		super();
	}
	public NegativeBalanceException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
