package com.revature.bms.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import java.sql.Connection;

import com.revature.bms.model.Customer;
import com.revature.bms.model.Employee;
import com.revature.bms.util.DBConnection;

public class EmployeeDaoImpl implements EmployeeDAO {
	Connection connection=DBConnection.getDBConnection();
	private final String ADD_EMPLOYEE_QUERY="insert into bank.employee values(?,?,?,?)";
	//private final String UPDATE_PPRODUCT_QUERY="update hr.product set product_name=?,product_price=?,product_stock=? where product_id=?";
	private final String VALIDATE_EMPLOYEE_QUERY="select * from bank.employee where employee_username = ? and employee_password = ?";
	private final String GET_ALL_CUSTOMERS_QUERY="select * from bank.customer";
	private final String GET_APPLIED_CUSTOMERS_QUERY="select * from bank.customer_applied";
	private final String DELETE_EMPLOYEE_QUERY="delete from bank.employee where employee_id=?";
	private final String EMPLOYEE_ALREADY_EXIST_QUERY="select * from bank.employee where employee_id=?";
	
	public boolean addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		int rs=0;
		try {
			PreparedStatement preparedStatement=connection.prepareStatement(ADD_EMPLOYEE_QUERY);
			preparedStatement.setInt(1, employee.getEmployeeId());
			preparedStatement.setString(2, employee.getEmployeeName());
			preparedStatement.setString(3, employee.getEmployeeUserName());
			preparedStatement.setString(4, employee.getEmployeePassword());
			rs=preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(rs==0) {
		return false;
		}
		else
		{
			return true;
		}
		
	}

	public boolean deleteEmployee(int employeeId) {
		// TODO Auto-generated method stub
		int rs=0;
		try {
			PreparedStatement preparedStatement=connection.prepareStatement(DELETE_EMPLOYEE_QUERY);
			preparedStatement.setInt(1, employeeId);
			
			
			rs=preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(rs==0) {
		return false;
		}
		else
		{
			return true;
		}
	}

	public boolean updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean validateEmployee(String employeeUserName,String employeePassword)
	{
		
		ResultSet res=null;
		int flag=0;
			try {
		    PreparedStatement preparedStatement=connection.prepareStatement(VALIDATE_EMPLOYEE_QUERY);
			preparedStatement.setString(1,employeeUserName);
			preparedStatement.setString(2,employeePassword);

			 res= preparedStatement.executeQuery();
			 if(res.next())
			 {
					//user is valid
					flag=1;
			 }
		
		
			}
			catch(Exception e) {
				
			}
			if(flag==1) {
				return true;
			}
			else
			{
				return false;
			}
		
		
	}

	public Employee getEmployeeUsingUsernamePassword(String employeeUserName, String employeePassword) {
		// TODO Auto-generated method stub
		ResultSet res=null;
		int employeeID=0;
		String employeeName=null;
		String employeeUsername=null;
		String employeePass=null;
			try {
		    PreparedStatement preparedStatement=connection.prepareStatement(VALIDATE_EMPLOYEE_QUERY);
			preparedStatement.setString(1,employeeUserName);
			preparedStatement.setString(2,employeePassword);

			 res= preparedStatement.executeQuery();
			 if(res.next())
			 {
					//user is valid
					employeeID=res.getInt(1);
					employeeName=res.getString(2);
					employeeUsername=res.getString(3);
					employeePass=res.getString(4);
			 }
		
		
			}
			catch(Exception e) {
				
			}
		return new Employee(employeeID, employeeName, employeeUsername, employeePass);
	}

	public List<Customer> getAllCustomerAccounts() {
		// TODO Auto-generated method stub
		List<Customer> customers=new ArrayList<Customer>();
		ResultSet rs=null;
		Customer customer=new Customer();
		try {
			Statement statement=connection.createStatement();
			rs=statement.executeQuery(GET_ALL_CUSTOMERS_QUERY);
			
			while(rs.next()) {
				customer.setCustomerId(rs.getInt(1));
				customer.setCustomerName(rs.getString(2));
				customer.setCustomerAddress(rs.getString(3));
				customer.setCustomerBalance(rs.getInt(4));
				customer.setCustomerUserName(rs.getString(5));
				customer.setCustomerPassword(rs.getString(6));
				customers.add(customer);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return customers;
	}

	public boolean isEmployeeAlreadyExist(int employeeId) {
		// TODO Auto-generated method stub
		ResultSet res=null;
		int flag=0;
			try {
		    PreparedStatement preparedStatement=connection.prepareStatement(EMPLOYEE_ALREADY_EXIST_QUERY);
			preparedStatement.setInt(1,employeeId);
			

			 res= preparedStatement.executeQuery();
			 if(res.next())
			 {
					//user is valid
					flag=1;
			 }
		
		
			}
			catch(Exception e) {
				
			}
			if(flag==1) {
				return true;
			}
			else
			{
				return false;
			}
		
	}

	public List<Customer> getAppliedCustomerAccounts() {
		// TODO Auto-generated method stub
		List<Customer> customers=new ArrayList<Customer>();
		ResultSet rs=null;
		Customer customer=new Customer();
		try {
			Statement statement=connection.createStatement();
			rs=statement.executeQuery(GET_APPLIED_CUSTOMERS_QUERY);
			
			while(rs.next()) {
				customer.setCustomerId(rs.getInt(1));
				customer.setCustomerName(rs.getString(2));
				customer.setCustomerAddress(rs.getString(3));
				customer.setCustomerBalance(rs.getInt(4));
				customer.setCustomerUserName(rs.getString(5));
				customer.setCustomerPassword(rs.getString(6));
				customers.add(customer);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return customers;
	}
	

}
