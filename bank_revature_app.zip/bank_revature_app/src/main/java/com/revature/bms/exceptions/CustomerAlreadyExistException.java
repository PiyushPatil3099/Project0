package com.revature.bms.exceptions;

public class CustomerAlreadyExistException extends RuntimeException {
	public CustomerAlreadyExistException() {
		// TODO Auto-generated constructor stub
		super();
	}
	public CustomerAlreadyExistException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
