package com.revature.bms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.revature.bms.model.Customer;
import com.revature.bms.util.DBConnection;

public class CustomerDAOImpl implements CustomerDAO {
	Connection connection=DBConnection.getDBConnection();
	private final String ADD_CUSTOMER_QUERY="insert into bank.customer values(?,?,?,?,?,?)";
	private final String ADD_APPLY_CUSTOMER_QUERY="insert into bank.customer_applied values(?,?,?,?,?,?)";
	private final String VALIDATE_CUSTOMER_QUERY="select * from bank.customer where customer_username=? and customer_password=?";
	private final String GET_CUSTOMER_BALANCE_QUERY="select customer_balance from bank.customer where customer_id=?";
	private final String DEPOSITE_CUSTOMER_QERY="update bank.customer set customer_balance=customer_balance+? where customer_id=?";
	private final String WITHDRAW_CUSTOMER_QERY="update bank.customer set customer_balance=customer_balance-? where customer_id=?";
	private final String DELETE_CUSTOMER_QUERY="delete from bank.customer where customer_id=?";
	private final String DELETE_APPLIED_CUSTOMER_QUERY="delete from bank.customer_applied where customer_id=?";
	private final String CUSTOMER_ALREADY_EXIST_QUERY="select * from bank.customer where customer_id=?";
	public boolean addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		int rs=0;
		try {
			PreparedStatement preparedStatement=connection.prepareStatement(ADD_CUSTOMER_QUERY);
			preparedStatement.setInt(1, customer.getCustomerId());
			preparedStatement.setString(2, customer.getCustomerName());
			preparedStatement.setString(3, customer.getCustomerAddress());
			preparedStatement.setInt(4, customer.getCustomerBalance());
			preparedStatement.setString(5, customer.getCustomerUserName());
			preparedStatement.setString(6, customer.getCustomerPassword());
			rs=preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(rs==0) {
		return false;
		}
		else
		{
			return true;
		}
	}

	public boolean deleteCustomer(int customerId) {
		// TODO Auto-generated method stub
		int rs=0;
		try {
			PreparedStatement preparedStatement=connection.prepareStatement(DELETE_CUSTOMER_QUERY);
			preparedStatement.setInt(1, customerId);
			
			
			rs=preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(rs==0) {
		return false;
		}
		else
		{
			return true;
		}
	}
	public boolean deleteAppliedCustomer(int customerId) {
		// TODO Auto-generated method stub
		int rs=0;
		try {
			PreparedStatement preparedStatement=connection.prepareStatement(DELETE_APPLIED_CUSTOMER_QUERY);
			preparedStatement.setInt(1, customerId);
			
			
			rs=preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(rs==0) {
		return false;
		}
		else
		{
			return true;
		}
	}

	public boolean validateCustomer(String customerUserName,String customerPassword)
	{
		
		ResultSet res=null;
		int flag=0;
			try {
		    PreparedStatement preparedStatement=connection.prepareStatement(VALIDATE_CUSTOMER_QUERY);
			preparedStatement.setString(1,customerUserName);
			preparedStatement.setString(2,customerPassword);

			 res= preparedStatement.executeQuery();
			 if(res.next())
			 {
					//user is valid
					flag=1;
			 }
		
		
			}
			catch(Exception e) {
				
			}
			if(flag==1) {
				return true;
			}
			else
			{
				return false;
			}
		
		
	}

	public boolean updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return false;
	}

	public Customer getCustomerIdFromUsernamePassword(String customerUserName, String customerPassword) {
		// TODO Auto-generated method stub
		ResultSet res=null;
		int customerID=0;
		String customerName=null;
		String customerAddress=null;
		int customerBalance=0;
		String customerUsername=null;
		String customerPass=null;
			try {
		    PreparedStatement preparedStatement=connection.prepareStatement(VALIDATE_CUSTOMER_QUERY);
			preparedStatement.setString(1,customerUserName);
			preparedStatement.setString(2,customerPassword);

			 res= preparedStatement.executeQuery();
			 if(res.next())
			 {
					//user is valid
					customerID=res.getInt(1);
					customerName=res.getString(2);
					customerAddress=res.getString(3);
					customerBalance=res.getInt(4);
					customerUsername=res.getString(5);
					customerPass=res.getString(6);
			 }
		
		
			}
			catch(Exception e) {
				
			}

		return new Customer(customerID, customerName, customerAddress, customerBalance, customerUsername, customerPass);
	}

	public int getCustomerBalanceFromID(int customerID) {
		// TODO Auto-generated method stub
		ResultSet res=null;
		int balance=0;
		  try {
			PreparedStatement preparedStatement=connection.prepareStatement(GET_CUSTOMER_BALANCE_QUERY);
			preparedStatement.setInt(1,customerID);
			res=preparedStatement.executeQuery();
			while(res.next()) {
				balance=res.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return balance;
	}

	public boolean depositeCustomerAmmount(int customerID,int customerUpdatedBalance) {
		// TODO Auto-generated method stub
		int rs=0;
		try {
			PreparedStatement preparedStatement=connection.prepareStatement(DEPOSITE_CUSTOMER_QERY);
			preparedStatement.setInt(1, customerUpdatedBalance);
			preparedStatement.setInt(2, customerID);
			
			rs=preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(rs==0) {
		return false;
		}
		else
		{
			return true;
		}
		
	}

	public boolean withdrawCustomerAmmount(int customerID, int customerUpdatedBalance) {
		// TODO Auto-generated method stub
		int rs=0;
		try {
			PreparedStatement preparedStatement=connection.prepareStatement(WITHDRAW_CUSTOMER_QERY);
			preparedStatement.setInt(1, customerUpdatedBalance);
			preparedStatement.setInt(2, customerID);
			
			rs=preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(rs==0) {
		return false;
		}
		else
		{
			return true;
		}
		
	}

	public boolean isCustomerAlreadyExist(int customerId) {
		// TODO Auto-generated method stub
		ResultSet res=null;
		int flag=0;
			try {
		    PreparedStatement preparedStatement=connection.prepareStatement(CUSTOMER_ALREADY_EXIST_QUERY);
			preparedStatement.setInt(1,customerId);
			

			 res= preparedStatement.executeQuery();
			 if(res.next())
			 {
					//user is valid
					flag=1;
			 }
		
		
			}
			catch(Exception e) {
				
			}
			if(flag==1) {
				return true;
			}
			else
			{
				return false;
			}

	}

	public boolean addAppliedCustomer(Customer customer) {
		// TODO Auto-generated method stub
		int rs=0;
		try {
			PreparedStatement preparedStatement=connection.prepareStatement(ADD_APPLY_CUSTOMER_QUERY);
			preparedStatement.setInt(1, customer.getCustomerId());
			preparedStatement.setString(2, customer.getCustomerName());
			preparedStatement.setString(3, customer.getCustomerAddress());
			preparedStatement.setInt(4, customer.getCustomerBalance());
			preparedStatement.setString(5, customer.getCustomerUserName());
			preparedStatement.setString(6, customer.getCustomerPassword());
			rs=preparedStatement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(rs==0) {
		return false;
		}
		else
		{
			return true;
		}
	}
	

}
