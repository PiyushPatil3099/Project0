package com.revature.bms.exceptions;

public class LowBalanceException extends RuntimeException {
	public LowBalanceException() {
		// TODO Auto-generated constructor stub
		super();
	}
	public LowBalanceException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
