package com.revature.bms.exceptions;

public class EmployeeAlreadyExistException extends RuntimeException {
	public EmployeeAlreadyExistException() {
		// TODO Auto-generated constructor stub
		super();
	}
	public EmployeeAlreadyExistException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
