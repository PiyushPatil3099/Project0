package com.revature.bms.dao;

import com.revature.bms.model.Customer;

public interface CustomerDAO {
	public boolean addCustomer(Customer customer);
	public boolean addAppliedCustomer(Customer customer);
	public boolean deleteCustomer(int CustomerId);
	public boolean deleteAppliedCustomer(int CustomerId);
	public boolean updateCustomer(Customer customer);
	public boolean validateCustomer(String customerUserName,String customerPassword);
	public Customer getCustomerIdFromUsernamePassword(String customerUserName,String customerPassword);
	public int getCustomerBalanceFromID(int customerID);
	public boolean depositeCustomerAmmount(int customerID,int balance);
	public boolean withdrawCustomerAmmount(int customerID,int balance);
	public boolean isCustomerAlreadyExist(int customerId);
	
}
