package com.revature.bms.dao;

import java.util.List;

import com.revature.bms.model.Customer;
import com.revature.bms.model.Employee;

public interface EmployeeDAO {
	public boolean addEmployee(Employee employee);
	public boolean deleteEmployee(int employeeId);
	public boolean updateEmployee(Employee employee);
	public boolean validateEmployee(String employeeUserName,String employeePassword);
	public Employee getEmployeeUsingUsernamePassword(String customerUserName,String customerPassword);
	public List<Customer> getAllCustomerAccounts();
	public List<Customer> getAppliedCustomerAccounts();
	public boolean isEmployeeAlreadyExist(int employeeId);
}
