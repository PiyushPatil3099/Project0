package com;



import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.revature.bms.dao.CustomerDAOImpl;
import com.revature.bms.dao.EmployeeDaoImpl;
import com.revature.bms.model.Customer;
import com.revature.bms.model.Employee;

public class BankTests {
	CustomerDAOImpl customerDAOImpl=null;
	EmployeeDaoImpl employeeDaoImpl=null;
	Customer customer=null;
	Employee employee=null;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
			customerDAOImpl=new CustomerDAOImpl();
			customer=new Customer(-999, "demo", "demo", 500, "demo", "demo");
			employeeDaoImpl=new EmployeeDaoImpl();
			employee=new Employee(-990, "demo", "demo", "demo");
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void addCustomertest() {
		boolean actual=customerDAOImpl.addCustomer(customer);
		boolean expected=true;
		assertEquals(expected,actual);
	}
	@Test
	public void depositeCustomerAmmounttest() {
		boolean actual=customerDAOImpl.depositeCustomerAmmount(2,500);
		boolean expected=true;
		assertEquals(expected,actual);

	}
	@Test
	public void withdrawCustomerAmmounttest() {
		boolean actual=customerDAOImpl.withdrawCustomerAmmount(2,500);
		boolean expected=true;
		assertEquals(expected,actual);

	}
	@Test
	public void validateCustomertest() {
		boolean actual=customerDAOImpl.validateCustomer("mayank@gmail.com","mayank");
		boolean expected=true;
		assertEquals(expected,actual);
	}
	
	@Test
	public void getCustomerIdtest() {
		Customer customer1=customerDAOImpl.getCustomerIdFromUsernamePassword("mayank@gmail.com","mayank");
		int actual=customer1.getCustomerId();
		int expected=2;
		assertEquals(expected,actual);
	}
	@Test
	public void deleteCustomertest() {
		boolean actual=customerDAOImpl.deleteCustomer(customer.getCustomerId());
		boolean expected=true;
		assertEquals(expected,actual);
	}
	
	
	@Test
	public void createEmployeetest() {
		boolean actual=employeeDaoImpl.addEmployee(employee);
		boolean expected=true;
		assertEquals(expected,actual);
	}
	@Test
	public void validateEmployeetest() {
		boolean actual=employeeDaoImpl.validateEmployee("piyush3099@gmail.com","Piyush3099");
		boolean expected=true;
		assertEquals(expected,actual);
	}
	@Test
	public void deleteEmployeetest() {
		boolean actual=employeeDaoImpl.deleteEmployee(employee.getEmployeeId()
				);
		boolean expected=true;
		assertEquals(expected,actual);
	}
	
}
